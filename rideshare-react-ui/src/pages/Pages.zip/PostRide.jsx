import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { apiRequest } from "../api";

const SHARED_STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');
  * { font-family: 'DM Sans', sans-serif; box-sizing: border-box; }
  body { margin: 0; background: #1a1a16; }
  .page-bg {
    background:
      radial-gradient(ellipse 65% 50% at 20% 5%, rgba(231,226,71,0.07) 0%, transparent 65%),
      radial-gradient(ellipse 45% 55% at 90% 90%, rgba(77,80,97,0.3) 0%, transparent 60%),
      #1a1a16;
    min-height: 100vh;
  }
  .grid-bg {
    background-image:
      linear-gradient(rgba(231,226,71,0.027) 1px, transparent 1px),
      linear-gradient(90deg, rgba(231,226,71,0.027) 1px, transparent 1px);
    background-size: 60px 60px;
  }
  .card-dark {
    background: rgba(61,59,48,0.3);
    border: 1px solid rgba(231,226,71,0.09);
    backdrop-filter: blur(12px);
    border-radius: 16px;
  }
  .input-field {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.1);
    color: #f4f4f5; width: 100%;
    padding: 0.82rem 1rem; border-radius: 10px;
    font-size: 0.88rem; outline: none;
    transition: border-color 0.2s, background 0.2s;
  }
  .input-field::placeholder { color: #52525b; }
  .input-field:focus { border-color: rgba(231,226,71,0.5); background: rgba(255,255,255,0.07); }
  .input-field.input-error { border-color: rgba(239,68,68,0.5); }
  select.input-field option { background: #22221a; color: #f4f4f5; }
  label {
    display: block; font-size: 0.73rem; color: #71717a;
    margin-bottom: 0.35rem; font-weight: 500;
    letter-spacing: 0.05em; text-transform: uppercase;
  }
  .field-error { color: #fca5a5; font-size: 0.74rem; margin-top: 0.3rem; }
  .glow-btn {
    background-color: #e7e247; color: #1a1a16; border: none; cursor: pointer;
    font-family: 'Syne', sans-serif; font-weight: 700; border-radius: 10px;
    transition: box-shadow 0.3s ease, transform 0.2s ease, opacity 0.2s;
  }
  .glow-btn:hover:not(:disabled) { box-shadow: 0 0 28px rgba(231,226,71,0.32); transform: translateY(-1px); }
  .glow-btn:disabled { opacity: 0.45; cursor: not-allowed; }
  .ghost-btn {
    background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1);
    color: #a1a1aa; cursor: pointer; border-radius: 10px;
    transition: border-color 0.2s, color 0.2s, background 0.2s;
  }
  .ghost-btn:hover { border-color: rgba(231,226,71,0.4); color: #e7e247; background: rgba(231,226,71,0.06); }
  .nav-blur {
    backdrop-filter: blur(16px);
    background: rgba(26,26,22,0.85);
    border-bottom: 1px solid rgba(231,226,71,0.07);
  }
  .avatar-circle {
    display: flex; align-items: center; justify-content: center;
    background: rgba(231,226,71,0.15); color: #e7e247;
    font-family: 'Syne', sans-serif; font-weight: 700;
    border-radius: 50%; cursor: pointer;
    border: 2px solid rgba(231,226,71,0.3);
    transition: border-color 0.2s, background 0.2s;
    flex-shrink: 0; user-select: none;
  }
  .avatar-circle:hover { border-color: #e7e247; background: rgba(231,226,71,0.25); }
  .dropdown-menu {
    position: absolute; top: calc(100% + 10px); right: 0;
    background: #22221a; border: 1px solid rgba(231,226,71,0.15);
    border-radius: 14px; padding: 0.5rem; min-width: 190px;
    box-shadow: 0 20px 50px rgba(0,0,0,0.5);
    animation: popIn 0.18s ease; z-index: 100;
  }
  @keyframes popIn {
    from { opacity: 0; transform: scale(0.95) translateY(-6px); }
    to   { opacity: 1; transform: scale(1) translateY(0); }
  }
  .drop-item {
    padding: 0.55rem 0.8rem; border-radius: 9px; cursor: pointer;
    font-size: 0.83rem; color: #a1a1aa;
    transition: background 0.15s, color 0.15s;
    display: flex; align-items: center; gap: 0.55rem;
  }
  .drop-item:hover { background: rgba(231,226,71,0.08); color: #f4f4f5; }
  .drop-item.danger:hover { background: rgba(239,68,68,0.1); color: #fca5a5; }
  .divider-line { height: 1px; background: rgba(255,255,255,0.07); margin: 0.3rem 0; }
  .tab-btn {
    padding: 0.4rem 0.9rem; border-radius: 8px; font-size: 0.82rem;
    cursor: pointer; font-family: 'Syne', sans-serif; font-weight: 600;
    transition: all 0.2s; border: none;
  }
  .tab-btn.on  { background: #e7e247; color: #1a1a16; }
  .tab-btn.off { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1) !important; color: #71717a; }
  .seat-btn {
    width: 42px; height: 42px; border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-family: 'Syne', sans-serif; font-weight: 700; font-size: 0.9rem;
    cursor: pointer; transition: all 0.2s;
  }
  .seat-btn.selected {
    background: #e7e247; color: #1a1a16; border: none;
    box-shadow: 0 0 14px rgba(231,226,71,0.3);
  }
  .seat-btn.unselected {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.1); color: #71717a;
  }
  .seat-btn.unselected:hover { border-color: rgba(231,226,71,0.4); color: #e7e247; }
  .step-badge {
    background: rgba(231,226,71,0.1); border: 1px solid rgba(231,226,71,0.2);
    border-radius: 6px; padding: 0.15rem 0.45rem;
    font-size: 0.72rem; color: #e7e247;
  }
  .preview-inner {
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(231,226,71,0.12);
    border-radius: 12px; padding: 1rem 1.1rem;
  }
  .success-overlay {
    position: fixed; inset: 0;
    background: rgba(0,0,0,0.7); backdrop-filter: blur(6px);
    z-index: 200; display: flex; align-items: center; justify-content: center;
    padding: 1rem; animation: fadeIn 0.25s ease;
  }
  .success-box {
    background: #22221a; border: 1px solid rgba(34,197,94,0.2);
    border-radius: 20px; padding: 2.25rem; max-width: 420px; width: 100%;
    box-shadow: 0 24px 60px rgba(0,0,0,0.6); text-align: center;
    animation: slideUp 0.3s ease;
  }
  @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
  @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
  @keyframes spin { to { transform: rotate(360deg); } }
  @keyframes fadeUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
  .fade-up { animation: fadeUp 0.38s ease forwards; }
  input[type="datetime-local"]::-webkit-calendar-picker-indicator { filter: invert(0.6); cursor: pointer; }
  input[type="number"]::-webkit-inner-spin-button,
  input[type="number"]::-webkit-outer-spin-button { -webkit-appearance: none; }
`;

const EMPTY_FORM   = { origin: "", destination: "", departureTime: "", availableSeats: 1, price: "" };
const EMPTY_ERRORS = { origin: "", destination: "", departureTime: "", price: "" };

// ─── Nav ──────────────────────────────────────────────────────────────────────
function NavBar({ user, navigate }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  const initials = user
    ? user.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase()
    : "?";

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <nav className="nav-blur" style={{ position: "sticky", top: 0, zIndex: 50, padding: "1rem 2rem", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", cursor: "pointer" }} onClick={() => navigate("/rides")}>
        <div style={{ width: 32, height: 32, background: "#e7e247", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "0.85rem", color: "#1a1a16" }}>R</span>
        </div>
        <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "1.05rem", color: "#f4f4f5" }}>RideShare</span>
      </div>

      <div style={{ display: "flex", gap: "0.3rem" }}>
        {[["Browse Rides", "/rides"], ["Post a Ride", "/post-ride"], ["My Bookings", "/bookings"]].map(([label, path]) => (
          <button key={path}
            className={`tab-btn ${window.location.pathname === path ? "on" : "off"}`}
            onClick={() => navigate(path)}
            style={{ padding: "0.4rem 0.9rem" }}>
            {label}
          </button>
        ))}
      </div>

      <div style={{ position: "relative" }} ref={ref}>
        <div className="avatar-circle" style={{ width: 38, height: 38, fontSize: "0.85rem" }} onClick={() => setOpen(!open)}>
          {initials}
        </div>
        {open && (
          <div className="dropdown-menu">
            {user && (
              <div style={{ padding: "0.5rem 0.8rem 0.65rem", borderBottom: "1px solid rgba(255,255,255,0.07)", marginBottom: "0.35rem" }}>
                <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "0.88rem", color: "#f4f4f5" }}>{user.name}</div>
                <div style={{ color: "#52525b", fontSize: "0.74rem", marginTop: "0.15rem" }}>{user.email}</div>
              </div>
            )}
            <div className="drop-item" onClick={() => { navigate("/profile"); setOpen(false); }}>👤 My Profile</div>
            <div className="drop-item" onClick={() => { navigate("/bookings"); setOpen(false); }}>📋 My Bookings</div>
            <div className="drop-item" onClick={() => { navigate("/post-ride"); setOpen(false); }}>🚗 Post a Ride</div>
            <div className="divider-line"></div>
            <div className="drop-item danger" onClick={handleLogout}>🚪 Sign Out</div>
          </div>
        )}
      </div>
    </nav>
  );
}

// ─── Post Ride Page ───────────────────────────────────────────────────────────
export default function PostRidePage() {
  const [user, setUser]           = useState(null);
  const [form, setForm]           = useState(EMPTY_FORM);
  const [errors, setErrors]       = useState(EMPTY_ERRORS);
  const [submitting, setSubmitting] = useState(false);
  const [apiError, setApiError]   = useState("");
  const [createdRide, setCreatedRide] = useState(null);
  const navigate = useNavigate();

  // ── Load current user for the preview card ──
  useEffect(() => {
    const loadUser = async () => {
      try {
        const res = await apiRequest("/api/profile");
        if (res.ok) {
          const u = await res.json();
          setUser(u);
        } else {
          console.error("Profile load failed:", await res.text());
        }
      } catch (err) {
        console.error("Profile fetch error:", err);
      }
    };
    loadUser();
  }, []);

  const setField = (k) => (e) => {
    setForm(f => ({ ...f, [k]: e.target.value }));
    setErrors(er => ({ ...er, [k]: "" }));
  };

  // ── Client-side validation ──
  const validate = () => {
    const e = { ...EMPTY_ERRORS };
    let valid = true;

    if (!form.origin.trim()) {
      e.origin = "Origin is required"; valid = false;
    }
    if (!form.destination.trim()) {
      e.destination = "Destination is required"; valid = false;
    } else if (form.origin.trim().toLowerCase() === form.destination.trim().toLowerCase()) {
      e.destination = "Origin and destination can't be the same"; valid = false;
    }
    if (!form.departureTime) {
      e.departureTime = "Departure time is required"; valid = false;
    } else if (new Date(form.departureTime) <= new Date()) {
      e.departureTime = "Departure must be in the future"; valid = false;
    }
    if (!form.price || isNaN(form.price) || +form.price <= 0) {
      e.price = "Enter a valid price greater than 0"; valid = false;
    }

    setErrors(e);
    return valid;
  };

  // ── Submit — mirrors Rides.jsx: apiRequest returns raw Response ──
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    setApiError("");

    try {
      // Backend RideRequest DTO expects: origin, destination, departureTime, availableSeats, price
      // departureTime must be ISO LocalDateTime string: "2025-06-01T09:30:00"
      const payload = {
        origin:         form.origin.trim(),
        destination:    form.destination.trim(),
        departureTime:  new Date(form.departureTime).toISOString().slice(0, 19),
        availableSeats: form.availableSeats,
        price:          parseFloat(form.price),
      };

      console.log("Posting ride:", payload);

      const res = await apiRequest("/api/rides/create", "POST", payload);

      if (res.ok) {
        const ride = await res.json();
        console.log("Ride created:", ride);
        setCreatedRide(ride);
      } else {
        const text = await res.text();
        console.error("Ride creation failed:", text);
        setApiError("Failed to post ride. Please try again.");
      }
    } catch (err) {
      console.error("Post ride error:", err);
      setApiError("Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  // ── Derived preview values ──
  const hasRoute = form.origin && form.destination;
  const hasTime  = !!form.departureTime;
  const hasPrice = form.price && !isNaN(form.price) && +form.price > 0;

  const deptPreview = hasTime
    ? new Date(form.departureTime).toLocaleString("en-US", { weekday: "short", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })
    : "—";

  // Step progress: lights up as each section is completed
  const step1done = !!(form.origin && form.destination);
  const step2done = !!(step1done && form.departureTime);
  const step3done = !!(step2done && form.price);

  // ── Success screen ──
  if (createdRide) {
    return (
      <div className="success-overlay">
        <style>{SHARED_STYLES}</style>
        <div className="success-box">
          <div style={{ fontSize: "3rem", marginBottom: "0.75rem" }}>🎉</div>
          <h2 style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "1.4rem", color: "#f4f4f5", margin: "0 0 0.5rem 0" }}>
            Ride Posted!
          </h2>
          <p style={{ color: "#71717a", fontSize: "0.88rem", lineHeight: 1.6, margin: "0 0 1.5rem 0" }}>
            Your ride from <strong style={{ color: "#f4f4f5" }}>{createdRide.origin}</strong> to{" "}
            <strong style={{ color: "#f4f4f5" }}>{createdRide.destination}</strong> is now live.
          </p>

          <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: "1rem", marginBottom: "1.5rem", textAlign: "left" }}>
            {[
              ["🕐", "Departure", createdRide.departureTime.split("T")[0] + " · " + createdRide.departureTime.split("T")[1].substring(0, 5)],
              ["💺", "Seats Available", `${createdRide.availableSeats}`],
              ["💰", "Price per Seat", `₹${createdRide.price}`],
              ["🔖", "Ride ID", `RS-${String(createdRide.id).padStart(5, "0")}`],
            ].map(([icon, k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0.35rem 0", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                <span style={{ color: "#71717a", fontSize: "0.8rem" }}>{icon} {k}</span>
                <span style={{ color: "#d4d4d8", fontSize: "0.82rem", fontWeight: 500 }}>{v}</span>
              </div>
            ))}
          </div>

          <div style={{ display: "flex", gap: "0.75rem" }}>
            <button className="ghost-btn" style={{ flex: 1, padding: "0.75rem", fontSize: "0.85rem" }}
              onClick={() => { setCreatedRide(null); setForm(EMPTY_FORM); setErrors(EMPTY_ERRORS); }}>
              + Post Another
            </button>
            <button className="glow-btn" style={{ flex: 1, padding: "0.75rem", fontSize: "0.85rem" }}
              onClick={() => navigate("/rides")}>
              Browse Rides →
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page-bg grid-bg">
      <style>{SHARED_STYLES}</style>
      <NavBar user={user} navigate={navigate} />

      <div style={{ maxWidth: 800, margin: "0 auto", padding: "2.5rem 1.5rem" }}>

        {/* ── Header ── */}
        <div className="fade-up" style={{ marginBottom: "2rem" }}>
          <p style={{ fontSize: "0.72rem", color: "#e7e247", letterSpacing: "0.1em", textTransform: "uppercase", margin: "0 0 0.3rem 0" }}>Driver Dashboard</p>
          <h1 style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "2rem", color: "#f4f4f5", lineHeight: 1.15, margin: "0 0 0.4rem 0" }}>Post a Ride</h1>
          <p style={{ color: "#71717a", fontSize: "0.88rem", margin: 0 }}>Fill your empty seats and split the cost of your journey.</p>
        </div>

        {/* ── Step progress indicator ── */}
        <div className="fade-up" style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "1.75rem" }}>
          {[
            [step1done, "Route", 1],
            [step2done, "Time", 2],
            [step3done, "Pricing", 3],
          ].map(([done, label, num], i, arr) => (
            <div key={label} style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "0.25rem" }}>
                <div style={{
                  width: 32, height: 32, borderRadius: "50%",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "0.8rem",
                  flexShrink: 0, transition: "all 0.3s",
                  background: done ? "rgba(34,197,94,0.15)" : "transparent",
                  border: `2px solid ${done ? "rgba(34,197,94,0.4)" : "rgba(231,226,71,0.2)"}`,
                  color: done ? "#86efac" : "#71717a",
                }}>
                  {done ? "✓" : num}
                </div>
                <span style={{ fontSize: "0.65rem", color: done ? "#86efac" : "#52525b", letterSpacing: "0.05em" }}>
                  {label}
                </span>
              </div>
              {i < arr.length - 1 && (
                <div style={{ flex: 1, height: 1, background: done ? "rgba(34,197,94,0.3)" : "rgba(255,255,255,0.07)", width: 40, marginBottom: "1rem", transition: "background 0.3s" }}></div>
              )}
            </div>
          ))}
        </div>

        {/* ── Form card ── */}
        <div className="card-dark fade-up" style={{ padding: "2rem", marginBottom: "1rem" }}>
          <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>

            {/* Section 01 — Route */}
            <div>
              <p style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "0.9rem", color: "#f4f4f5", margin: "0 0 1rem 0", display: "flex", alignItems: "center", gap: "0.5rem" }}>
                <span className="step-badge">01</span>
                Route Details
              </p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.85rem" }}>
                <div>
                  <label>From — Origin</label>
                  <div style={{ position: "relative" }}>
                    <span style={{ position: "absolute", left: "0.9rem", top: "50%", transform: "translateY(-50%)", fontSize: "0.8rem", pointerEvents: "none" }}>🟢</span>
                    <input
                      className={`input-field${errors.origin ? " input-error" : ""}`}
                      style={{ paddingLeft: "2.4rem" }}
                      placeholder="e.g. Downtown"
                      value={form.origin}
                      onChange={setField("origin")}
                    />
                  </div>
                  {errors.origin && <p className="field-error">{errors.origin}</p>}
                </div>
                <div>
                  <label>To — Destination</label>
                  <div style={{ position: "relative" }}>
                    <span style={{ position: "absolute", left: "0.9rem", top: "50%", transform: "translateY(-50%)", fontSize: "0.8rem", pointerEvents: "none" }}>🟡</span>
                    <input
                      className={`input-field${errors.destination ? " input-error" : ""}`}
                      style={{ paddingLeft: "2.4rem" }}
                      placeholder="e.g. Airport"
                      value={form.destination}
                      onChange={setField("destination")}
                    />
                  </div>
                  {errors.destination && <p className="field-error">{errors.destination}</p>}
                </div>
              </div>
            </div>

            <div style={{ height: 1, background: "rgba(255,255,255,0.06)" }}></div>

            {/* Section 02 — Departure time */}
            <div>
              <p style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "0.9rem", color: "#f4f4f5", margin: "0 0 1rem 0", display: "flex", alignItems: "center", gap: "0.5rem" }}>
                <span className="step-badge">02</span>
                Departure Time
              </p>
              <div>
                <label>Date & Time</label>
                <input
                  className={`input-field${errors.departureTime ? " input-error" : ""}`}
                  type="datetime-local"
                  value={form.departureTime}
                  onChange={setField("departureTime")}
                  min={new Date(Date.now() + 5 * 60000).toISOString().slice(0, 16)}
                />
                {errors.departureTime
                  ? <p className="field-error">{errors.departureTime}</p>
                  : <p style={{ color: "#52525b", fontSize: "0.75rem", marginTop: "0.4rem" }}>Must be at least 5 minutes from now</p>
                }
              </div>
            </div>

            <div style={{ height: 1, background: "rgba(255,255,255,0.06)" }}></div>

            {/* Section 03 — Seats + Price */}
            <div>
              <p style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "0.9rem", color: "#f4f4f5", margin: "0 0 1rem 0", display: "flex", alignItems: "center", gap: "0.5rem" }}>
                <span className="step-badge">03</span>
                Seats & Pricing
              </p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.25rem", alignItems: "start" }}>

                {/* Seat picker */}
                <div>
                  <label>Available Seats</label>
                  <div style={{ display: "flex", gap: "0.4rem", flexWrap: "wrap" }}>
                    {[1, 2, 3, 4].map(n => (
                      <button key={n} type="button"
                        className={`seat-btn ${form.availableSeats === n ? "selected" : "unselected"}`}
                        onClick={() => setForm(f => ({ ...f, availableSeats: n }))}>
                        {n}
                      </button>
                    ))}
                  </div>
                  <p style={{ color: "#52525b", fontSize: "0.73rem", marginTop: "0.45rem" }}>How many empty seats are you offering?</p>
                </div>

                {/* Price */}
                <div>
                  <label>Price per Seat</label>
                  <div style={{ position: "relative" }}>
                    <span style={{ position: "absolute", left: "0.9rem", top: "50%", transform: "translateY(-50%)", color: "#71717a", fontSize: "0.9rem", fontFamily: "Syne, sans-serif", fontWeight: 700, pointerEvents: "none" }}>₹</span>
                    <input
                      className={`input-field${errors.price ? " input-error" : ""}`}
                      style={{ paddingLeft: "1.8rem" }}
                      type="number" min="0" step="0.5"
                      placeholder="0.00"
                      value={form.price}
                      onChange={setField("price")}
                    />
                  </div>
                  {errors.price && <p className="field-error">{errors.price}</p>}
                  <p style={{ color: "#52525b", fontSize: "0.73rem", marginTop: "0.45rem" }}>Set a fair price to attract riders</p>
                </div>
              </div>
            </div>

            {/* API error */}
            {apiError && (
              <div style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.25)", borderRadius: 10, padding: "0.65rem 1rem", color: "#fca5a5", fontSize: "0.82rem" }}>
                ⚠ {apiError}
              </div>
            )}

            {/* Submit */}
            <button type="submit" className="glow-btn" disabled={submitting}
              style={{ padding: "1rem", fontSize: "0.95rem", display: "flex", alignItems: "center", justifyContent: "center", gap: "0.6rem", marginTop: "0.25rem" }}>
              {submitting && (
                <span style={{ width: 15, height: 15, border: "2px solid rgba(26,26,22,0.4)", borderTopColor: "#1a1a16", borderRadius: "50%", animation: "spin 0.7s linear infinite", display: "inline-block" }}></span>
              )}
              {submitting ? "Posting your ride…" : "🚗 Post This Ride"}
            </button>
          </form>
        </div>

        {/* ── Live Preview ── */}
        <div className="card-dark" style={{ padding: "1.5rem" }}>
          <p style={{ fontSize: "0.72rem", color: "#71717a", letterSpacing: "0.08em", textTransform: "uppercase", margin: "0 0 1rem 0" }}>Live Preview</p>

          <div className="preview-inner" style={{ marginBottom: "1rem" }}>
            <div style={{ display: "flex", gap: "1rem", alignItems: "flex-start", marginBottom: "0.85rem" }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, paddingTop: "0.15rem" }}>
                <div style={{ width: 9, height: 9, background: hasRoute ? "#22c55e" : "rgba(255,255,255,0.12)", borderRadius: "50%", transition: "background 0.3s" }}></div>
                <div style={{ width: 1, height: 22, background: "rgba(255,255,255,0.1)" }}></div>
                <div style={{ width: 9, height: 9, background: hasRoute ? "#e7e247" : "rgba(255,255,255,0.12)", borderRadius: "2px", transition: "background 0.3s" }}></div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ color: form.origin ? "#a1a1aa" : "#3f3f46", fontSize: "0.82rem", marginBottom: "0.35rem", transition: "color 0.2s" }}>
                  {form.origin || "Origin"}
                </div>
                <div style={{ color: form.destination ? "#f4f4f5" : "#3f3f46", fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "0.9rem", transition: "color 0.2s" }}>
                  {form.destination || "Destination"}
                </div>
              </div>
            </div>

            <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
              <span style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 7, padding: "0.25rem 0.6rem", color: hasTime ? "#a1a1aa" : "#3f3f46", fontSize: "0.75rem", transition: "color 0.2s" }}>
                🕐 {deptPreview}
              </span>
              <span style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 7, padding: "0.25rem 0.6rem", color: "#a1a1aa", fontSize: "0.75rem" }}>
                💺 {form.availableSeats} seat{form.availableSeats !== 1 ? "s" : ""}
              </span>
            </div>
          </div>

          {/* Driver + price row */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              <div style={{ width: 28, height: 28, background: "rgba(231,226,71,0.12)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Syne, sans-serif", fontWeight: 700, color: "#e7e247", fontSize: "0.72rem" }}>
                {user?.name?.charAt(0).toUpperCase() || "?"}
              </div>
              <span style={{ color: "#71717a", fontSize: "0.78rem" }}>{user?.name || "You (Driver)"}</span>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "1.3rem", color: hasPrice ? "#e7e247" : "#3f3f46", transition: "color 0.3s" }}>
                {hasPrice ? `₹${parseFloat(form.price).toFixed(2)}` : "₹—"}
              </div>
              <div style={{ color: "#52525b", fontSize: "0.7rem" }}>per seat</div>
            </div>
          </div>

          {/* Tips */}
          <div style={{ marginTop: "1.25rem", paddingTop: "1rem", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
            <p style={{ fontSize: "0.72rem", color: "#52525b", letterSpacing: "0.06em", textTransform: "uppercase", margin: "0 0 0.6rem 0" }}>Driver Tips</p>
            {[
              ["💡", "Cheaper rides fill faster — keep your price fair"],
              ["🕐", "Post at least 1 hour before departure"],
              ["💬", "Respond quickly to booking requests"],
            ].map(([icon, tip]) => (
              <div key={tip} style={{ display: "flex", gap: "0.5rem", marginBottom: "0.4rem", alignItems: "flex-start" }}>
                <span style={{ fontSize: "0.78rem", flexShrink: 0, marginTop: "0.05rem" }}>{icon}</span>
                <span style={{ color: "#52525b", fontSize: "0.76rem", lineHeight: 1.45 }}>{tip}</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
