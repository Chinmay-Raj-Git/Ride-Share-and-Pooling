import { useState, useEffect, useRef, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { apiRequest } from "../api";

const SHARED_STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');
  * { font-family: 'DM Sans', sans-serif; box-sizing: border-box; }
  body { margin: 0; background: #1a1a16; }
  .page-bg {
    background:
      radial-gradient(ellipse 60% 45% at 80% 8%, rgba(231,226,71,0.06) 0%, transparent 65%),
      radial-gradient(ellipse 40% 50% at 5% 85%, rgba(77,80,97,0.3) 0%, transparent 60%),
      #1a1a16;
    min-height: 100vh;
  }
  .grid-bg {
    background-image:
      linear-gradient(rgba(231,226,71,0.025) 1px, transparent 1px),
      linear-gradient(90deg, rgba(231,226,71,0.025) 1px, transparent 1px);
    background-size: 60px 60px;
  }
  .card-dark {
    background: rgba(61,59,48,0.28);
    border: 1px solid rgba(231,226,71,0.09);
    backdrop-filter: blur(12px);
    border-radius: 16px;
  }
  .booking-card {
    background: rgba(61,59,48,0.28);
    border: 1px solid rgba(231,226,71,0.09);
    backdrop-filter: blur(10px);
    border-radius: 14px;
    transition: transform 0.22s ease, box-shadow 0.22s ease, border-color 0.22s ease;
  }
  .booking-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 36px rgba(0,0,0,0.35);
    border-color: rgba(231,226,71,0.2);
  }
  .input-field {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.1);
    color: #f4f4f5; padding: 0.7rem 1rem;
    border-radius: 10px; font-size: 0.85rem;
    outline: none; transition: border-color 0.2s;
  }
  .input-field::placeholder { color: #52525b; }
  .input-field:focus { border-color: rgba(231,226,71,0.45); }
  select.input-field option { background: #22221a; color: #f4f4f5; }
  .glow-btn {
    background-color: #e7e247; color: #1a1a16; border: none; cursor: pointer;
    font-family: 'Syne', sans-serif; font-weight: 700; border-radius: 10px;
    transition: box-shadow 0.3s ease, transform 0.2s ease, opacity 0.2s;
  }
  .glow-btn:hover:not(:disabled) { box-shadow: 0 0 25px rgba(231,226,71,0.3); transform: translateY(-1px); }
  .glow-btn:disabled { opacity: 0.45; cursor: not-allowed; }
  .ghost-btn {
    background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1);
    color: #a1a1aa; cursor: pointer; border-radius: 10px;
    transition: border-color 0.2s, color 0.2s, background 0.2s;
  }
  .ghost-btn:hover, .ghost-btn.active {
    border-color: rgba(231,226,71,0.4); color: #e7e247; background: rgba(231,226,71,0.06);
  }
  .danger-btn {
    background: rgba(239,68,68,0.09); border: 1px solid rgba(239,68,68,0.2);
    color: #fca5a5; cursor: pointer; border-radius: 10px;
    transition: background 0.2s, border-color 0.2s; font-size: 0.78rem;
  }
  .danger-btn:hover:not(:disabled) { background: rgba(239,68,68,0.18); border-color: rgba(239,68,68,0.4); }
  .danger-btn:disabled { opacity: 0.4; cursor: not-allowed; }
  .nav-blur {
    backdrop-filter: blur(16px);
    background: rgba(26,26,22,0.85);
    border-bottom: 1px solid rgba(231,226,71,0.07);
  }
  .avatar-circle {
    display: flex; align-items: center; justify-content: center;
    background: rgba(231,226,71,0.15); color: #e7e247;
    font-family: 'Syne', sans-serif; font-weight: 700;
    border-radius: 50%; cursor: pointer;
    border: 2px solid rgba(231,226,71,0.3);
    transition: border-color 0.2s, background 0.2s;
    flex-shrink: 0; user-select: none;
  }
  .avatar-circle:hover { border-color: #e7e247; background: rgba(231,226,71,0.25); }
  .dropdown-menu {
    position: absolute; top: calc(100% + 10px); right: 0;
    background: #22221a; border: 1px solid rgba(231,226,71,0.15);
    border-radius: 14px; padding: 0.5rem; min-width: 190px;
    box-shadow: 0 20px 50px rgba(0,0,0,0.5);
    animation: popIn 0.18s ease; z-index: 100;
  }
  @keyframes popIn {
    from { opacity: 0; transform: scale(0.95) translateY(-6px); }
    to   { opacity: 1; transform: scale(1) translateY(0); }
  }
  .drop-item {
    padding: 0.55rem 0.8rem; border-radius: 9px; cursor: pointer;
    font-size: 0.83rem; color: #a1a1aa;
    transition: background 0.15s, color 0.15s;
    display: flex; align-items: center; gap: 0.55rem;
  }
  .drop-item:hover { background: rgba(231,226,71,0.08); color: #f4f4f5; }
  .drop-item.danger:hover { background: rgba(239,68,68,0.1); color: #fca5a5; }
  .divider-line { height: 1px; background: rgba(255,255,255,0.07); margin: 0.3rem 0; }
  .tab-btn {
    padding: 0.4rem 0.9rem; border-radius: 8px; font-size: 0.82rem;
    cursor: pointer; font-family: 'Syne', sans-serif; font-weight: 600;
    transition: all 0.2s; border: none;
  }
  .tab-btn.on  { background: #e7e247; color: #1a1a16; }
  .tab-btn.off { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1) !important; color: #71717a; }
  .stat-pill {
    background: rgba(61,59,48,0.4); border: 1px solid rgba(231,226,71,0.08);
    border-radius: 10px; padding: 0.55rem 1rem;
    display: flex; align-items: center; gap: 0.4rem;
  }
  .modal-bg {
    position: fixed; inset: 0;
    background: rgba(0,0,0,0.65); backdrop-filter: blur(5px);
    z-index: 200; display: flex; align-items: center; justify-content: center;
    padding: 1rem; animation: fadeIn 0.2s ease;
  }
  .modal-box {
    background: #22221a; border: 1px solid rgba(231,226,71,0.15);
    border-radius: 18px; padding: 1.75rem; max-width: 380px; width: 100%;
    box-shadow: 0 24px 60px rgba(0,0,0,0.55); animation: slideUp 0.25s ease;
  }
  @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
  @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
  @keyframes spin { to { transform: rotate(360deg); } }
  @keyframes fadeUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
  .fade-up { animation: fadeUp 0.38s ease forwards; }
`;

// ─── Nav ──────────────────────────────────────────────────────────────────────
function NavBar({ user, navigate }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  const initials = user
    ? user.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase()
    : "?";

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <nav className="nav-blur" style={{ position: "sticky", top: 0, zIndex: 50, padding: "1rem 2rem", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", cursor: "pointer" }} onClick={() => navigate("/rides")}>
        <div style={{ width: 32, height: 32, background: "#e7e247", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "0.85rem", color: "#1a1a16" }}>R</span>
        </div>
        <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "1.05rem", color: "#f4f4f5" }}>RideShare</span>
      </div>

      <div style={{ display: "flex", gap: "0.3rem" }}>
        {[["Browse Rides", "/rides"], ["Post a Ride", "/post-ride"], ["My Bookings", "/bookings"]].map(([label, path]) => (
          <button key={path}
            className={`tab-btn ${window.location.pathname === path ? "on" : "off"}`}
            onClick={() => navigate(path)}
            style={{ padding: "0.4rem 0.9rem" }}>
            {label}
          </button>
        ))}
      </div>

      <div style={{ position: "relative" }} ref={ref}>
        <div className="avatar-circle" style={{ width: 38, height: 38, fontSize: "0.85rem" }} onClick={() => setOpen(!open)}>
          {initials}
        </div>
        {open && (
          <div className="dropdown-menu">
            {user && (
              <div style={{ padding: "0.5rem 0.8rem 0.65rem", borderBottom: "1px solid rgba(255,255,255,0.07)", marginBottom: "0.35rem" }}>
                <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "0.88rem", color: "#f4f4f5" }}>{user.name}</div>
                <div style={{ color: "#52525b", fontSize: "0.74rem", marginTop: "0.15rem" }}>{user.email}</div>
              </div>
            )}
            <div className="drop-item" onClick={() => { navigate("/profile"); setOpen(false); }}>👤 My Profile</div>
            <div className="drop-item" onClick={() => { navigate("/bookings"); setOpen(false); }}>📋 My Bookings</div>
            <div className="drop-item" onClick={() => { navigate("/post-ride"); setOpen(false); }}>🚗 Post a Ride</div>
            <div className="divider-line"></div>
            <div className="drop-item danger" onClick={handleLogout}>🚪 Sign Out</div>
          </div>
        )}
      </div>
    </nav>
  );
}

// ─── Confirm Cancel Modal ─────────────────────────────────────────────────────
function ConfirmModal({ onConfirm, onCancel, cancelling }) {
  return (
    <div className="modal-bg" onClick={e => e.target === e.currentTarget && onCancel()}>
      <div className="modal-box">
        <div style={{ fontSize: "2rem", marginBottom: "0.75rem", textAlign: "center" }}>⚠️</div>
        <h3 style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "1.05rem", color: "#f4f4f5", textAlign: "center", margin: "0 0 0.5rem 0" }}>
          Cancel this booking?
        </h3>
        <p style={{ color: "#71717a", fontSize: "0.85rem", textAlign: "center", margin: "0 0 1.5rem 0", lineHeight: 1.5 }}>
          The seat will be released back to the driver. This cannot be undone.
        </p>
        <div style={{ display: "flex", gap: "0.75rem" }}>
          <button className="ghost-btn" style={{ flex: 1, padding: "0.7rem" }} onClick={onCancel}>
            Keep Booking
          </button>
          <button className="danger-btn" style={{ flex: 1, padding: "0.7rem", display: "flex", alignItems: "center", justifyContent: "center", gap: "0.5rem" }}
            onClick={onConfirm} disabled={cancelling}>
            {cancelling && <span style={{ width: 13, height: 13, border: "2px solid rgba(252,165,165,0.3)", borderTopColor: "#fca5a5", borderRadius: "50%", animation: "spin 0.7s linear infinite", display: "inline-block" }}></span>}
            {cancelling ? "Cancelling…" : "Yes, Cancel"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── My Bookings Page ─────────────────────────────────────────────────────────
export default function MyBookingsPage() {
  const [user, setUser]           = useState(null);
  const [bookings, setBookings]   = useState([]);
  const [loading, setLoading]     = useState(true);
  const [filter, setFilter]       = useState("all");   // all | upcoming | past
  const [sortBy, setSortBy]       = useState("newest");
  const [flash, setFlash]         = useState("");      // { msg, type }
  const [confirmId, setConfirmId] = useState(null);
  const [cancelling, setCancelling] = useState(false);
  const navigate = useNavigate();

  // ── Load profile + bookings on mount ──
  useEffect(() => {
    const loadAll = async () => {
      try {
        const [profileRes, bookingsRes] = await Promise.all([
          apiRequest("/api/profile"),
          apiRequest("/api/bookings/my"),
        ]);

        if (profileRes.ok) {
          const u = await profileRes.json();
          setUser(u);
        } else {
          console.error("Failed to load profile", await profileRes.text());
        }

        if (bookingsRes.ok) {
          const b = await bookingsRes.json();
          console.log("My bookings:", b);
          setBookings(b);
        } else {
          console.error("Failed to load bookings", await bookingsRes.text());
        }

      } catch (err) {
        console.error("Load error:", err);
        navigate("/login");
      } finally {
        setLoading(false);
      }
    };
    loadAll();
  }, []);

  // ── Cancel booking ──
  const handleCancel = async () => {
    setCancelling(true);
    try {
      const res = await apiRequest(`/api/bookings/cancel/${confirmId}`, "DELETE");
      if (res.ok) {
        setBookings(bs => bs.filter(b => b.id !== confirmId));
        setFlash({ msg: "Booking cancelled. Seat returned to driver.", type: "ok" });
        console.log("Booking cancelled:", confirmId);
      } else {
        const text = await res.text();
        console.error("Cancel failed:", text);
        setFlash({ msg: "Failed to cancel booking.", type: "err" });
      }
    } catch (err) {
      console.error("Cancel error:", err);
      setFlash({ msg: "Something went wrong.", type: "err" });
    } finally {
      setCancelling(false);
      setConfirmId(null);
      setTimeout(() => setFlash(""), 4000);
    }
  };

  // ── Derived values ──
  const now = new Date();

  const processed = useMemo(() => {
    let result = bookings.map(b => ({
      ...b,
      deptDate: new Date(b.ride?.departureTime),
    }));

    if (filter === "upcoming") result = result.filter(b => b.deptDate >= now);
    if (filter === "past")     result = result.filter(b => b.deptDate <  now);

    if (sortBy === "newest")    result = [...result].sort((a, z) => new Date(z.bookingTime) - new Date(a.bookingTime));
    else if (sortBy === "oldest") result = [...result].sort((a, z) => new Date(a.bookingTime) - new Date(z.bookingTime));
    else if (sortBy === "departure") result = [...result].sort((a, z) => a.deptDate - z.deptDate);

    return result;
  }, [bookings, filter, sortBy]);

  const upcomingCount = bookings.filter(b => new Date(b.ride?.departureTime) >= now).length;
  const totalSpent    = bookings.reduce((s, b) => s + (b.ride?.price || 0), 0);

  // ── Loading state ──
  if (loading) {
    return (
      <div className="page-bg grid-bg" style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "100vh" }}>
        <style>{SHARED_STYLES}</style>
        <div style={{ textAlign: "center" }}>
          <div style={{ width: 28, height: 28, border: "3px solid rgba(231,226,71,0.2)", borderTopColor: "#e7e247", borderRadius: "50%", animation: "spin 0.7s linear infinite", margin: "0 auto 1rem" }}></div>
          <div style={{ color: "#52525b", fontSize: "0.85rem" }}>Loading your bookings…</div>
        </div>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  return (
    <div className="page-bg grid-bg">
      <style>{SHARED_STYLES}</style>
      <NavBar user={user} navigate={navigate} />

      <div style={{ maxWidth: 1000, margin: "0 auto", padding: "2.5rem 1.5rem" }}>

        {/* ── Page header ── */}
        <div className="fade-up" style={{ marginBottom: "1.75rem" }}>
          <p style={{ fontSize: "0.72rem", color: "#e7e247", letterSpacing: "0.1em", textTransform: "uppercase", margin: "0 0 0.3rem 0" }}>Your Journeys</p>
          <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: "1rem" }}>
            <h1 style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "2rem", color: "#f4f4f5", lineHeight: 1.15, margin: 0 }}>My Bookings</h1>
            <button className="glow-btn" style={{ padding: "0.6rem 1.25rem", fontSize: "0.85rem" }} onClick={() => navigate("/rides")}>
              + Book Another Ride
            </button>
          </div>
        </div>

        {/* ── Stats row ── */}
        <div className="fade-up" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(155px, 1fr))", gap: "0.75rem", marginBottom: "1.5rem" }}>
          {[
            ["📋", bookings.length,                   "Total Bookings"],
            ["🟢", upcomingCount,                     "Upcoming"],
            ["📅", bookings.length - upcomingCount,   "Past Rides"],
            ["💰", `₹${totalSpent.toFixed(2)}`,       "Total Spent"],
          ].map(([icon, val, lbl]) => (
            <div key={lbl} className="stat-pill">
              <span style={{ fontSize: "1rem" }}>{icon}</span>
              <div>
                <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "1.05rem", color: "#e7e247" }}>{val}</div>
                <div style={{ color: "#52525b", fontSize: "0.7rem" }}>{lbl}</div>
              </div>
            </div>
          ))}
        </div>

        {/* ── Filter + sort bar ── */}
        <div className="card-dark" style={{ padding: "1rem 1.25rem", marginBottom: "1.25rem", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "0.75rem" }}>
          <div style={{ display: "flex", gap: "0.35rem" }}>
            {[["all", "All"], ["upcoming", "Upcoming"], ["past", "Past"]].map(([k, l]) => (
              <button key={k} className={`tab-btn ${filter === k ? "on" : "off"}`} onClick={() => setFilter(k)}>
                {l}
                {k === "upcoming" && upcomingCount > 0 && (
                  <span style={{ background: "rgba(34,197,94,0.2)", color: "#86efac", borderRadius: 99, padding: "0 0.35rem", fontSize: "0.68rem", marginLeft: "0.3rem" }}>
                    {upcomingCount}
                  </span>
                )}
              </button>
            ))}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <span style={{ color: "#52525b", fontSize: "0.75rem" }}>Sort:</span>
            <select className="input-field" value={sortBy} onChange={e => setSortBy(e.target.value)}
              style={{ padding: "0.45rem 0.75rem", fontSize: "0.8rem", width: "auto" }}>
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
              <option value="departure">By departure</option>
            </select>
          </div>
        </div>

        {/* ── Flash message ── */}
        {flash && (
          <div style={{
            background: flash.type === "err" ? "rgba(239,68,68,0.1)" : "rgba(34,197,94,0.08)",
            border: `1px solid ${flash.type === "err" ? "rgba(239,68,68,0.25)" : "rgba(34,197,94,0.2)"}`,
            borderRadius: 10, padding: "0.65rem 1rem",
            color: flash.type === "err" ? "#fca5a5" : "#86efac",
            fontSize: "0.82rem", marginBottom: "1rem"
          }}>
            {flash.type === "err" ? "⚠ " : "✅ "}{flash.msg}
          </div>
        )}

        {/* ── Bookings list ── */}
        {processed.length === 0 ? (
          <div className="card-dark" style={{ padding: "3.5rem 2rem", textAlign: "center" }}>
            <div style={{ fontSize: "2.5rem", marginBottom: "0.75rem" }}>🎒</div>
            <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "1rem", color: "#71717a", marginBottom: "0.4rem" }}>
              {filter === "all" ? "No bookings yet" : `No ${filter} rides`}
            </div>
            <div style={{ color: "#52525b", fontSize: "0.85rem", marginBottom: "1.25rem" }}>
              {filter === "all" ? "Find a ride and book your first seat." : "Try switching the filter above."}
            </div>
            {filter === "all" && (
              <button className="glow-btn" style={{ padding: "0.65rem 1.5rem", fontSize: "0.85rem" }} onClick={() => navigate("/rides")}>
                Browse Available Rides →
              </button>
            )}
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: "0.85rem" }}>
            {processed.map(booking => {
              const ride       = booking.ride;
              const isUpcoming = booking.deptDate >= now;
              const bookDate   = new Date(booking.bookingTime);
              const deptDate   = booking.deptDate;

              return (
                <div key={booking.id} className="booking-card" style={{ padding: "1.25rem" }}>
                  <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: "1rem" }}>

                    {/* Route + driver */}
                    <div style={{ display: "flex", gap: "1rem", flex: 1, minWidth: 220 }}>
                      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", paddingTop: "0.2rem", gap: 3 }}>
                        <div style={{ width: 9, height: 9, background: "#22c55e", borderRadius: "50%" }}></div>
                        <div style={{ width: 1, height: 28, background: "rgba(255,255,255,0.12)" }}></div>
                        <div style={{ width: 9, height: 9, background: "#e7e247", borderRadius: "2px" }}></div>
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ color: "#a1a1aa", fontSize: "0.8rem", marginBottom: "0.2rem" }}>
                          {ride?.origin || "—"}
                        </div>
                        <div style={{ color: "#f4f4f5", fontSize: "0.92rem", fontWeight: 600, fontFamily: "Syne, sans-serif", marginBottom: "0.5rem" }}>
                          {ride?.destination || "—"}
                        </div>
                        {ride?.driver && (
                          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                            <div style={{ width: 24, height: 24, background: "rgba(231,226,71,0.14)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Syne, sans-serif", fontWeight: 700, color: "#e7e247", fontSize: "0.7rem", flexShrink: 0 }}>
                              {ride.driver.name?.charAt(0).toUpperCase()}
                            </div>
                            <span style={{ color: "#71717a", fontSize: "0.78rem" }}>
                              Driver: <span style={{ color: "#d4d4d8" }}>{ride.driver.name}</span>
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Meta */}
                    <div style={{ display: "flex", flexDirection: "column", gap: "0.4rem", minWidth: 180 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}>
                        <span style={{ fontSize: "0.75rem" }}>🕐</span>
                        <span style={{ color: "#a1a1aa", fontSize: "0.78rem" }}>
                          {ride?.departureTime
                            ? `${ride.departureTime.split("T")[0]} · ${ride.departureTime.split("T")[1].substring(0, 5)}`
                            : "—"}
                        </span>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}>
                        <span style={{ fontSize: "0.75rem" }}>🎟</span>
                        <span style={{ color: "#a1a1aa", fontSize: "0.78rem" }}>
                          Booked {bookDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                        </span>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}>
                        <span style={{ fontSize: "0.75rem" }}>🔖</span>
                        <span style={{ color: "#52525b", fontSize: "0.72rem", fontFamily: "monospace" }}>
                          BK-{String(booking.id).padStart(5, "0")}
                        </span>
                      </div>
                    </div>

                    {/* Price + status + action */}
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "0.6rem", flexShrink: 0 }}>
                      <span style={{
                        display: "inline-flex", alignItems: "center", padding: "0.18rem 0.55rem",
                        borderRadius: 6, fontSize: "0.7rem", fontWeight: 500,
                        background: isUpcoming ? "rgba(34,197,94,0.12)" : "rgba(113,113,122,0.1)",
                        color: isUpcoming ? "#86efac" : "#71717a",
                        border: `1px solid ${isUpcoming ? "rgba(34,197,94,0.2)" : "rgba(113,113,122,0.15)"}`,
                      }}>
                        {isUpcoming ? "Upcoming" : "Completed"}
                      </span>
                      <div style={{ textAlign: "right" }}>
                        <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "1.2rem", color: "#e7e247" }}>
                          ₹{ride?.price || "—"}
                        </div>
                        <div style={{ color: "#52525b", fontSize: "0.7rem" }}>per seat</div>
                      </div>
                      {isUpcoming && (
                        <button className="danger-btn" style={{ padding: "0.4rem 0.85rem" }}
                          onClick={() => setConfirmId(booking.id)}>
                          Cancel Booking
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Upcoming confirmation strip */}
                  {isUpcoming && (
                    <div style={{ marginTop: "0.85rem", paddingTop: "0.75rem", borderTop: "1px solid rgba(255,255,255,0.05)", display: "flex", alignItems: "center", gap: "0.5rem" }}>
                      <div style={{ width: 6, height: 6, background: "#22c55e", borderRadius: "50%" }}></div>
                      <span style={{ color: "#52525b", fontSize: "0.75rem" }}>Confirmed · Check your email for ride details</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Bottom CTA */}
        {bookings.length > 0 && (
          <div style={{ textAlign: "center", marginTop: "2.5rem", paddingTop: "1.5rem", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
            <p style={{ color: "#52525b", fontSize: "0.82rem", marginBottom: "0.85rem" }}>Going somewhere? Share your journey and fill your seats.</p>
            <button className="glow-btn" style={{ padding: "0.7rem 1.75rem", fontSize: "0.88rem" }} onClick={() => navigate("/post-ride")}>
              🚗 Post a Ride
            </button>
          </div>
        )}
      </div>

      {/* Confirm cancel modal */}
      {confirmId && (
        <ConfirmModal
          onConfirm={handleCancel}
          onCancel={() => setConfirmId(null)}
          cancelling={cancelling}
        />
      )}
    </div>
  );
}
