import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { apiRequest } from "../api";

const SHARED_STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');
  * { font-family: 'DM Sans', sans-serif; box-sizing: border-box; }
  body { margin: 0; background: #1a1a16; }
  .page-bg {
    background:
      radial-gradient(ellipse 65% 50% at 75% 5%, rgba(231,226,71,0.07) 0%, transparent 65%),
      radial-gradient(ellipse 45% 55% at 8% 90%, rgba(77,80,97,0.32) 0%, transparent 60%),
      #1a1a16;
    min-height: 100vh;
  }
  .grid-bg {
    background-image:
      linear-gradient(rgba(231,226,71,0.028) 1px, transparent 1px),
      linear-gradient(90deg, rgba(231,226,71,0.028) 1px, transparent 1px);
    background-size: 60px 60px;
  }
  .card-dark {
    background: rgba(61,59,48,0.3);
    border: 1px solid rgba(231,226,71,0.09);
    backdrop-filter: blur(12px);
    border-radius: 16px;
  }
  .input-field {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.1);
    color: #f4f4f5;
    width: 100%;
    padding: 0.8rem 1rem;
    border-radius: 10px;
    font-size: 0.88rem;
    outline: none;
    transition: border-color 0.2s, background 0.2s;
  }
  .input-field::placeholder { color: #52525b; }
  .input-field:focus { border-color: rgba(231,226,71,0.5); background: rgba(255,255,255,0.07); }
  label {
    display: block; font-size: 0.73rem; color: #71717a;
    margin-bottom: 0.35rem; font-weight: 500;
    letter-spacing: 0.05em; text-transform: uppercase;
  }
  .glow-btn {
    background-color: #e7e247; color: #1a1a16; border: none; cursor: pointer;
    font-family: 'Syne', sans-serif; font-weight: 700; border-radius: 10px;
    transition: box-shadow 0.3s ease, transform 0.2s ease, opacity 0.2s;
  }
  .glow-btn:hover:not(:disabled) { box-shadow: 0 0 28px rgba(231,226,71,0.32); transform: translateY(-1px); }
  .glow-btn:disabled { opacity: 0.45; cursor: not-allowed; }
  .ghost-btn {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.1);
    color: #a1a1aa; cursor: pointer; border-radius: 10px;
    transition: border-color 0.2s, color 0.2s, background 0.2s;
  }
  .ghost-btn:hover, .ghost-btn.active {
    border-color: rgba(231,226,71,0.4);
    color: #e7e247;
    background: rgba(231,226,71,0.06);
  }
  .nav-blur {
    backdrop-filter: blur(16px);
    background: rgba(26,26,22,0.85);
    border-bottom: 1px solid rgba(231,226,71,0.07);
  }
  .avatar-circle {
    display: flex; align-items: center; justify-content: center;
    background: rgba(231,226,71,0.15); color: #e7e247;
    font-family: 'Syne', sans-serif; font-weight: 700;
    border-radius: 50%; cursor: pointer;
    border: 2px solid rgba(231,226,71,0.3);
    transition: border-color 0.2s, background 0.2s;
    flex-shrink: 0; user-select: none;
  }
  .avatar-circle:hover { border-color: #e7e247; background: rgba(231,226,71,0.25); }
  .dropdown-menu {
    position: absolute; top: calc(100% + 10px); right: 0;
    background: #22221a; border: 1px solid rgba(231,226,71,0.15);
    border-radius: 14px; padding: 0.5rem; min-width: 190px;
    box-shadow: 0 20px 50px rgba(0,0,0,0.5);
    animation: popIn 0.18s ease; z-index: 100;
  }
  @keyframes popIn {
    from { opacity: 0; transform: scale(0.95) translateY(-6px); }
    to   { opacity: 1; transform: scale(1) translateY(0); }
  }
  .drop-item {
    padding: 0.55rem 0.8rem; border-radius: 9px; cursor: pointer;
    font-size: 0.83rem; color: #a1a1aa;
    transition: background 0.15s, color 0.15s;
    display: flex; align-items: center; gap: 0.55rem;
  }
  .drop-item:hover { background: rgba(231,226,71,0.08); color: #f4f4f5; }
  .drop-item.danger:hover { background: rgba(239,68,68,0.1); color: #fca5a5; }
  .divider-line { height: 1px; background: rgba(255,255,255,0.07); margin: 0.3rem 0; }
  .tab-btn {
    padding: 0.45rem 1.1rem; border-radius: 8px; font-size: 0.82rem;
    cursor: pointer; font-family: 'Syne', sans-serif; font-weight: 600;
    transition: all 0.2s; border: none;
  }
  .tab-btn.on  { background: #e7e247; color: #1a1a16; }
  .tab-btn.off { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1) !important; color: #71717a; }
  .stat-left-border {
    background: rgba(61,59,48,0.22); border: 1px solid rgba(231,226,71,0.08);
    border-left: 3px solid #e7e247; border-radius: 12px; padding: 1rem 1.25rem;
  }
  .ride-row {
    background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06);
    border-radius: 12px; padding: 1rem;
    transition: border-color 0.2s;
  }
  .ride-row:hover { border-color: rgba(231,226,71,0.2); }
  .field-display {
    background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.07);
    border-radius: 10px; padding: 0.75rem 1rem;
    color: #d4d4d8; font-size: 0.88rem;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
  @keyframes fadeUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
  .fade-up { animation: fadeUp 0.38s ease forwards; }
`;

// ─── Avatar + Dropdown Nav ────────────────────────────────────────────────────
function NavBar({ user, navigate }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  const initials = user
    ? user.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase()
    : "?";

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <nav className="nav-blur" style={{ position: "sticky", top: 0, zIndex: 50, padding: "1rem 2rem", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      {/* Logo */}
      <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", cursor: "pointer" }} onClick={() => navigate("/rides")}>
        <div style={{ width: 32, height: 32, background: "#e7e247", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "0.85rem", color: "#1a1a16" }}>R</span>
        </div>
        <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "1.05rem", color: "#f4f4f5" }}>RideShare</span>
      </div>

      {/* Nav links */}
      <div style={{ display: "flex", gap: "0.3rem" }}>
        {[["Browse Rides", "/rides"], ["Post a Ride", "/post-ride"], ["My Bookings", "/bookings"]].map(([label, path]) => (
          <button key={path}
            className={`tab-btn ${window.location.pathname === path ? "on" : "off"}`}
            onClick={() => navigate(path)}
            style={{ padding: "0.4rem 0.9rem" }}>
            {label}
          </button>
        ))}
      </div>

      {/* Avatar dropdown */}
      <div style={{ position: "relative" }} ref={ref}>
        <div className="avatar-circle" style={{ width: 38, height: 38, fontSize: "0.85rem" }} onClick={() => setOpen(!open)}>
          {initials}
        </div>
        {open && (
          <div className="dropdown-menu">
            {user && (
              <div style={{ padding: "0.5rem 0.8rem 0.65rem", borderBottom: "1px solid rgba(255,255,255,0.07)", marginBottom: "0.35rem" }}>
                <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "0.88rem", color: "#f4f4f5" }}>{user.name}</div>
                <div style={{ color: "#52525b", fontSize: "0.74rem", marginTop: "0.15rem" }}>{user.email}</div>
              </div>
            )}
            <div className="drop-item" onClick={() => { navigate("/profile"); setOpen(false); }}>👤 My Profile</div>
            <div className="drop-item" onClick={() => { navigate("/bookings"); setOpen(false); }}>📋 My Bookings</div>
            <div className="drop-item" onClick={() => { navigate("/post-ride"); setOpen(false); }}>🚗 Post a Ride</div>
            <div className="divider-line"></div>
            <div className="drop-item danger" onClick={handleLogout}>🚪 Sign Out</div>
          </div>
        )}
      </div>
    </nav>
  );
}

// ─── Profile Page ─────────────────────────────────────────────────────────────
export default function ProfilePage() {
  const [user, setUser]       = useState(null);
  const [myRides, setMyRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab]         = useState("details");
  const [editMode, setEditMode] = useState(false);
  const [editForm, setEditForm] = useState({ name: "", email: "", contact: "" });
  const [saving, setSaving]   = useState(false);
  const [saveMsg, setSaveMsg] = useState("");
  const navigate = useNavigate();

  // ── Load profile + my rides on mount ──
  useEffect(() => {
    const loadAll = async () => {
      try {
        const [profileRes, ridesRes] = await Promise.all([
          apiRequest("/api/profile"),
          apiRequest("/api/rides/my"),
        ]);

        if (profileRes.ok) {
          const u = await profileRes.json();
          setUser(u);
          setEditForm({ name: u.name, email: u.email, contact: u.contact || "" });
        } else {
          console.error("Failed to load profile", await profileRes.text());
          navigate("/login");
        }

        if (ridesRes.ok) {
          const r = await ridesRes.json();
          console.log("My rides:", r);
          setMyRides(r);
        } else {
          console.error("Failed to load my rides", await ridesRes.text());
        }

      } catch (err) {
        console.error("Profile load error:", err);
        navigate("/login");
      } finally {
        setLoading(false);
      }
    };
    loadAll();
  }, []);

  // ── Save edits (PUT /api/profile when implemented) ──
  const handleSave = async () => {
    setSaving(true);
    setSaveMsg("");
    try {
      // PUT /api/profile endpoint — update when backend adds it
      // const res = await apiRequest("/api/profile", "PUT", editForm);
      // if (!res.ok) throw new Error(await res.text());
      // Optimistic update for now:
      await new Promise(r => setTimeout(r, 600));
      setUser(u => ({ ...u, ...editForm }));
      setEditMode(false);
      setSaveMsg("Profile updated successfully.");
      setTimeout(() => setSaveMsg(""), 3500);
    } catch (err) {
      console.error("Save error:", err);
      setSaveMsg("Error: " + err.message);
    } finally {
      setSaving(false);
    }
  };

  const setField = (k) => (e) => setEditForm(f => ({ ...f, [k]: e.target.value }));

  // ── Loading state ──
  if (loading) {
    return (
      <div className="page-bg grid-bg" style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "100vh" }}>
        <style>{SHARED_STYLES}</style>
        <div style={{ textAlign: "center" }}>
          <div style={{ width: 28, height: 28, border: "3px solid rgba(231,226,71,0.2)", borderTopColor: "#e7e247", borderRadius: "50%", animation: "spin 0.7s linear infinite", margin: "0 auto 1rem" }}></div>
          <div style={{ color: "#52525b", fontSize: "0.85rem" }}>Loading your profile…</div>
        </div>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  const initials = user
    ? user.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase()
    : "?";

  return (
    <div className="page-bg grid-bg">
      <style>{SHARED_STYLES}</style>
      <NavBar user={user} navigate={navigate} />

      <div style={{ maxWidth: 960, margin: "0 auto", padding: "2.5rem 1.5rem" }}>

        {/* ── Hero card ── */}
        <div className="card-dark fade-up" style={{ padding: "2rem", marginBottom: "1.5rem", display: "flex", flexWrap: "wrap", alignItems: "center", gap: "1.5rem" }}>
          <div className="avatar-circle" style={{ width: 72, height: 72, fontSize: "1.5rem", cursor: "default" }}>{initials}</div>

          <div style={{ flex: 1, minWidth: 180 }}>
            <p style={{ fontSize: "0.72rem", color: "#e7e247", letterSpacing: "0.1em", textTransform: "uppercase", margin: "0 0 0.3rem 0" }}>Your Profile</p>
            <h1 style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "1.6rem", color: "#f4f4f5", lineHeight: 1.15, margin: 0 }}>{user.name}</h1>
            <p style={{ color: "#71717a", fontSize: "0.85rem", marginTop: "0.3rem" }}>{user.email}</p>
          </div>

          <div style={{ display: "flex", gap: "1rem", alignItems: "center", flexWrap: "wrap" }}>
            <div className="stat-left-border" style={{ textAlign: "center", minWidth: 80 }}>
              <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "1.4rem", color: "#e7e247" }}>{myRides.length}</div>
              <div style={{ color: "#71717a", fontSize: "0.72rem", marginTop: "0.15rem" }}>Rides Posted</div>
            </div>
            <div style={{ display: "flex", gap: "0.6rem" }}>
              <button
                className="glow-btn"
                style={{ padding: "0.55rem 1.1rem", fontSize: "0.82rem" }}
                onClick={() => { setEditMode(!editMode); setSaveMsg(""); setTab("details"); }}>
                {editMode ? "✕ Cancel" : "✏ Edit Profile"}
              </button>
              <button
                className="ghost-btn"
                style={{ padding: "0.55rem 1.1rem", fontSize: "0.82rem" }}
                onClick={() => navigate("/bookings")}>
                📋 My Bookings
              </button>
            </div>
          </div>
        </div>

        {/* ── Tabs ── */}
        <div style={{ display: "flex", gap: "0.4rem", marginBottom: "1.25rem" }}>
          {[["details", "👤 Details"], ["rides", "🚗 My Rides"]].map(([k, l]) => (
            <button key={k} className={`tab-btn ${tab === k ? "on" : "off"}`} onClick={() => setTab(k)}>{l}</button>
          ))}
        </div>

        {/* Save message */}
        {saveMsg && (
          <div style={{
            background: saveMsg.startsWith("Error") ? "rgba(239,68,68,0.1)" : "rgba(34,197,94,0.08)",
            border: `1px solid ${saveMsg.startsWith("Error") ? "rgba(239,68,68,0.25)" : "rgba(34,197,94,0.2)"}`,
            borderRadius: 10, padding: "0.65rem 1rem",
            color: saveMsg.startsWith("Error") ? "#fca5a5" : "#86efac",
            fontSize: "0.82rem", marginBottom: "1rem"
          }}>
            {saveMsg.startsWith("Error") ? "⚠ " : "✅ "}{saveMsg}
          </div>
        )}

        {/* ── Details tab ── */}
        {tab === "details" && (
          <div className="card-dark fade-up" style={{ padding: "1.75rem" }}>
            <h2 style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "1rem", color: "#f4f4f5", marginBottom: "1.25rem", margin: "0 0 1.25rem 0" }}>
              {editMode ? "Edit Your Information" : "Account Information"}
            </h2>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px,1fr))", gap: "1.25rem" }}>
              {/* Name */}
              <div>
                <label>Full Name</label>
                {editMode
                  ? <input className="input-field" value={editForm.name} onChange={setField("name")} placeholder="Your full name" />
                  : <div className="field-display">{user.name}</div>}
              </div>

              {/* Email */}
              <div>
                <label>Email Address</label>
                {editMode
                  ? <input className="input-field" type="email" value={editForm.email} onChange={setField("email")} placeholder="you@email.com" />
                  : <div className="field-display">{user.email}</div>}
              </div>

              {/* Contact */}
              <div>
                <label>Contact Number</label>
                {editMode
                  ? <input className="input-field" value={editForm.contact} onChange={setField("contact")} placeholder="+1 555 000 0000" />
                  : <div className="field-display">{user.contact || <span style={{ color: "#52525b" }}>Not set</span>}</div>}
              </div>

              {/* Member ID — always read-only */}
              <div>
                <label>Member ID</label>
                <div className="field-display" style={{ color: "#52525b", fontFamily: "monospace" }}>
                  RS-{String(user.id).padStart(6, "0")}
                </div>
              </div>
            </div>

            {editMode && (
              <div style={{ marginTop: "1.5rem", display: "flex", justifyContent: "flex-end", gap: "0.75rem" }}>
                <button className="ghost-btn" style={{ padding: "0.65rem 1.25rem", fontSize: "0.85rem" }}
                  onClick={() => { setEditMode(false); setEditForm({ name: user.name, email: user.email, contact: user.contact || "" }); }}>
                  Cancel
                </button>
                <button className="glow-btn" style={{ padding: "0.65rem 1.4rem", fontSize: "0.85rem", display: "flex", alignItems: "center", gap: "0.5rem" }}
                  onClick={handleSave} disabled={saving}>
                  {saving && <span style={{ width: 13, height: 13, border: "2px solid rgba(26,26,22,0.4)", borderTopColor: "#1a1a16", borderRadius: "50%", animation: "spin 0.7s linear infinite", display: "inline-block" }}></span>}
                  {saving ? "Saving…" : "Save Changes"}
                </button>
              </div>
            )}

            {/* Quick actions */}
            {!editMode && (
              <div style={{ marginTop: "1.75rem", paddingTop: "1.25rem", borderTop: "1px solid rgba(255,255,255,0.06)", display: "flex", flexWrap: "wrap", gap: "0.75rem" }}>
                <button className="glow-btn" style={{ padding: "0.6rem 1.2rem", fontSize: "0.82rem" }} onClick={() => navigate("/post-ride")}>
                  🚗 Post a New Ride
                </button>
                <button className="ghost-btn" style={{ padding: "0.6rem 1.2rem", fontSize: "0.82rem" }} onClick={() => navigate("/bookings")}>
                  📋 My Bookings
                </button>
                <button className="ghost-btn" style={{ padding: "0.6rem 1.2rem", fontSize: "0.82rem" }} onClick={() => navigate("/rides")}>
                  🔍 Browse All Rides
                </button>
              </div>
            )}
          </div>
        )}

        {/* ── My Rides tab ── */}
        {tab === "rides" && (
          <div className="fade-up">
            {myRides.length === 0 ? (
              <div className="card-dark" style={{ padding: "3.5rem 2rem", textAlign: "center" }}>
                <div style={{ fontSize: "2.5rem", marginBottom: "0.75rem" }}>🚗</div>
                <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: "1rem", color: "#71717a", marginBottom: "0.4rem" }}>No rides posted yet</div>
                <div style={{ color: "#52525b", fontSize: "0.85rem", marginBottom: "1.25rem" }}>Share your journey and earn back fuel costs</div>
                <button className="glow-btn" style={{ padding: "0.65rem 1.5rem", fontSize: "0.85rem" }} onClick={() => navigate("/post-ride")}>
                  Post Your First Ride →
                </button>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
                {myRides.map(ride => {
                  const dt = new Date(ride.departureTime);
                  const isPast = dt < new Date();
                  const seats = ride.availableSeats;

                  return (
                    <div key={ride.id} className="ride-row">
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "0.75rem" }}>

                        {/* Route */}
                        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", flex: 1, minWidth: 180 }}>
                          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
                            <div style={{ width: 8, height: 8, background: "#22c55e", borderRadius: "50%" }}></div>
                            <div style={{ width: 1, height: 14, background: "rgba(255,255,255,0.12)" }}></div>
                            <div style={{ width: 8, height: 8, background: "#e7e247", borderRadius: "2px" }}></div>
                          </div>
                          <div>
                            <div style={{ color: "#a1a1aa", fontSize: "0.8rem" }}>{ride.origin}</div>
                            <div style={{ color: "#f4f4f5", fontSize: "0.85rem", fontWeight: 500 }}>{ride.destination}</div>
                          </div>
                        </div>

                        {/* Chips */}
                        <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", alignItems: "center" }}>
                          <span style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 7, padding: "0.25rem 0.6rem", color: "#a1a1aa", fontSize: "0.75rem" }}>
                            🕐 {ride.departureTime.split("T")[0]} · {ride.departureTime.split("T")[1].substring(0, 5)}
                          </span>
                          <span style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 7, padding: "0.25rem 0.6rem", color: "#a1a1aa", fontSize: "0.75rem" }}>
                            💺 {seats} seat{seats !== 1 ? "s" : ""}
                          </span>
                          <span style={{
                            display: "inline-flex", alignItems: "center", padding: "0.18rem 0.55rem",
                            borderRadius: 6, fontSize: "0.7rem", fontWeight: 500,
                            background: seats === 0 ? "rgba(239,68,68,0.1)" : isPast ? "rgba(113,113,122,0.1)" : "rgba(34,197,94,0.12)",
                            color: seats === 0 ? "#fca5a5" : isPast ? "#71717a" : "#86efac",
                            border: `1px solid ${seats === 0 ? "rgba(239,68,68,0.2)" : isPast ? "rgba(113,113,122,0.15)" : "rgba(34,197,94,0.2)"}`,
                          }}>
                            {seats === 0 ? "Full" : isPast ? "Past" : "Active"}
                          </span>
                        </div>

                        {/* Price */}
                        <div style={{ textAlign: "right", flexShrink: 0 }}>
                          <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "1.15rem", color: "#e7e247" }}>₹{ride.price}</div>
                          <div style={{ color: "#52525b", fontSize: "0.7rem" }}>per seat</div>
                        </div>
                      </div>
                    </div>
                  );
                })}

                <div style={{ textAlign: "center", marginTop: "0.75rem" }}>
                  <button className="glow-btn" style={{ padding: "0.65rem 1.5rem", fontSize: "0.85rem" }} onClick={() => navigate("/post-ride")}>
                    + Post Another Ride
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
